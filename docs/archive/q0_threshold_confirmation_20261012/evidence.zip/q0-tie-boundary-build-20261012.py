import os,sys,json,time,sysconfig,subprocess,hashlib
from pathlib import Path
R=Path.cwd();sys.path.insert(0,str(R));from scripts.research_record import write_record

out=R/'.local_agent/q0-tie-boundary-20261012';out.mkdir(exist_ok=True)
s=(R/'.local_agent/q0-tie-threshold-20261012/threshold1/native_module.c').read_text(encoding='utf-8')
s=s.replace('            score = branch <= -confirmed_incumbent', '            if (branch < -confirmed_incumbent) { ctx->control = 4; break; }\n            score = branch <= -confirmed_incumbent')
a='    uint64_t phase_final_nanoseconds;';assert s.count(a)==1
s=s.replace(a,a+'\n    uint64_t shadow_unit_losses;\n    uint64_t shadow_checks;\n    uint64_t shadow_ties;\n    uint64_t shadow_losses;\n    uint64_t shadow_mismatches;\n    uint64_t shadow_nodes;')
a='''            score = branch <= -confirmed_incumbent
                ? confirmed_incumbent : -branch;''';assert s.count(a)==1
s=s.replace(a,'''            int classified_tie = branch <= -confirmed_incumbent;
            int threshold_branch = branch;
            GCSemanticTable *saved_tt = ctx->tt;
            uint64_t nodes_before = ctx->nodes;
            ctx->tt = NULL;
            int shadow = gc_semantic_iterative_negamax(
                ctx, ply + 1, depth - 1, -GC_SEMANTIC_PROBE_INF,
                GC_SEMANTIC_PROBE_INF, 1, 0);
            ctx->tt = saved_tt;
            ctx->shadow_nodes += ctx->nodes - nodes_before;
            if (ctx->control != 0) { ctx->root_tie_aborts++; break; }
            ctx->shadow_checks++;\n            if (shadow == -confirmed_incumbent + 1) ctx->shadow_unit_losses++;
            if (classified_tie) ctx->shadow_ties++; else ctx->shadow_losses++;
            if ((classified_tie && shadow != -confirmed_incumbent) ||
                (!classified_tie && shadow <= -confirmed_incumbent)) {
                ctx->shadow_mismatches++;
                ctx->control = 4;
                break;
            }
            score = classified_tie ? confirmed_incumbent : -threshold_branch;''')
a='        gc_semantic_set_u64(out, "root_tie_refinements", ctx.root_tie_refinements) != 0 ||';assert s.count(a)==1
s=s.replace(a,'        gc_semantic_set_u64(out, "shadow_unit_losses", ctx.shadow_unit_losses) != 0 ||\n        gc_semantic_set_u64(out, "shadow_checks", ctx.shadow_checks) != 0 ||\n        gc_semantic_set_u64(out, "shadow_ties", ctx.shadow_ties) != 0 ||\n        gc_semantic_set_u64(out, "shadow_losses", ctx.shadow_losses) != 0 ||\n        gc_semantic_set_u64(out, "shadow_mismatches", ctx.shadow_mismatches) != 0 ||\n        gc_semantic_set_u64(out, "shadow_nodes", ctx.shadow_nodes) != 0 ||\n'+a)
variants={'shadow':s}
write_record(out/'declaration.json',dict(question='Do actual accepted/rejected thresholdties match independent fullwindow TTfree child values for every observedcandidate?',calls=12,roots=['gen2','seed1202root0','seed1204root0'],depths=[3,4],orders=[0,1],seconds=64,max_nodes=None,scope='Private diagnostic only: aftereachactual threshold query, temporarily removeTT for independent fullwindow samehorizon childscore, restoreTT evenonabort. Countties/losses/contradictions andshadowextra nodes; totalcost notdeploymentcost. Exactfulltuple compareclosedcounterfree fixtures. Samefullhistory/materialorder/canonicaltrace. No UI/default/labels/rescue. Expectedunder1min,max13min.'))
rows=[]
for arm,src in variants.items():
 d=out/arm;d.mkdir(exist_ok=True);p=d/'native_module.c';p.write_text(src,encoding='utf-8',newline='\n');binary=d/('_native_core'+sysconfig.get_config_var('EXT_SUFFIX'))
 args=[str(R/'.venv/Lib/site-packages/ziglang/zig.exe'),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+sysconfig.get_paths()['include'],'-I'+str(R/'generic_chess/_native'),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython312']+[str(p if f.name=='native_module.c' else f) for f in sorted((R/'generic_chess/_native').glob('*.c'))]+['-o',str(binary)]
 t=time.perf_counter();r=subprocess.run(args,env=dict(os.environ,ZIG_GLOBAL_CACHE_DIR=str(R/'.gc_zig_cache')),capture_output=True,text=True,timeout=180);(d/'compiler-private.txt').write_text(r.stdout+r.stderr,encoding='utf-8');assert r.returncode==0,r.stderr[-1000:];rows.append(dict(arm=arm,seconds=time.perf_counter()-t,source_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest()));print(arm,'built',flush=True)
write_record(out/'build.json',rows)