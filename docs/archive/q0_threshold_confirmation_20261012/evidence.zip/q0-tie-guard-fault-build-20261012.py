import sys,os,sysconfig,subprocess,time,hashlib
from pathlib import Path
R=Path.cwd();sys.path.insert(0,str(R))
from scripts.research_record import write_record
out=R/'.local_agent/q0-tie-guard-fault-20261012';out.mkdir(exist_ok=True)
s=(R/'generic_chess/_native/native_module.c').read_text(encoding='utf-8')
needle='            if (branch < -confirmed_incumbent) {'
assert s.count(needle)==1
v=s.replace(needle, '            branch = -confirmed_incumbent - 1;\n'+needle)
write_record(out/'build-declaration.json',dict(question='Does an actual injected contradictory fail-soft bound reject the interrupted iteration?',scope='Private fault injection in currentproduction thresholdguard, after actualtrigger/completedthresholdcall. No deployment or valueclaim; restore sameinput root; retain previouscompletediteration.'))
rows=[]

for name,src in [('fault',v)]:
 d=out/name;d.mkdir(exist_ok=True);p=d/'native_module.c';p.write_text(src,encoding='utf-8',newline='\n');binary=d/('_native_core'+sysconfig.get_config_var('EXT_SUFFIX'))
 args=[str(R/'.venv/Lib/site-packages/ziglang/zig.exe'),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+sysconfig.get_paths()['include'],'-I'+str(R/'generic_chess/_native'),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython312']+[str(p if f.name=='native_module.c' else f) for f in sorted((R/'generic_chess/_native').glob('*.c'))]+['-o',str(binary)]
 t=time.perf_counter();r=subprocess.run(args,env=dict(os.environ,ZIG_GLOBAL_CACHE_DIR=str(R/'.gc_zig_cache')),capture_output=True,text=True,timeout=180);(d/'compiler-private.txt').write_text(r.stdout+r.stderr,encoding='utf-8');assert r.returncode==0,r.stderr[-1000:]
 rows.append(dict(arm=name,seconds=time.perf_counter()-t,source_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest()));print(name,'built',flush=True)
write_record(out/'build.json',rows)
