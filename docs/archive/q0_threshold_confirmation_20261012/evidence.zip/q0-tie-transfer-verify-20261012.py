import sys,json
from pathlib import Path
R=Path.cwd();sys.path.insert(0,str(R));from scripts.research_record import write_record
p=R/'.local_agent/q0-tie-threshold-20261012/finite';d=json.loads((p/'result.json').read_bytes());assert d['complete'] and not d['censored'];rows=d['rows'];assert len(rows)==56;fields=['score','action','principal_variation','completed_depth'];summary=[]
for root in sorted({x['root'] for x in rows}):
 for depth in [3,4]:
  cells=[x for x in rows if x['root']==root and x['requested_depth']==depth]
  for order in [0,1]:
   a=next(x for x in cells if x['order']==order and x['arm']=='baseline');b=next(x for x in cells if x['order']==order and x['arm']=='threshold1');assert all(a['result'][k]==b['result'][k] for k in fields);assert a['result']['completed_depth']==b['result']['completed_depth']==depth
  a=next(x for x in cells if x['order']==0 and x['arm']=='baseline');b=next(x for x in cells if x['order']==0 and x['arm']=='threshold1');summary.append(dict(root=root,depth=depth,baseline_nodes=a['result']['nodes'],candidate_nodes=b['result']['nodes']))
write_record(p/'verification.json',dict(calls=56,fulltuple_pairs=28,all_requested_depths_complete=True,named_arm_mapping=True,summary=summary))
p=R/'.local_agent/q0-tie-threshold-delivery-20261012';d=json.loads((p/'result.json').read_bytes());assert d['complete'];rows=d['rows'];assert len(rows)==16;summary=[]
for root in sorted({x['root'] for x in rows}):
 for arm in ['baseline','threshold1']:
  a,b=[x for x in rows if x['root']==root and x['arm']==arm];assert all(a['result'][k]==b['result'][k] for k in fields)
 a=next(x for x in rows if x['root']==root and x['arm']=='baseline' and x['order']==0);b=next(x for x in rows if x['root']==root and x['arm']=='threshold1' and x['order']==0)
 if a['result']['completed_depth']==b['result']['completed_depth']:assert all(a['result'][k]==b['result'][k] for k in fields)
 summary.append(dict(root=root,depths=[a['result']['completed_depth'],b['result']['completed_depth']],scores=[a['result']['score'],b['result']['score']],attempted_visits=[a['result']['nodes'],b['result']['nodes']]))
write_record(p/'verification.json',dict(calls=16,reverse_fulltuple_pairs=8,summary=summary,scope='Actualequal16s/1M4exposed roots, no rootordering change, no strength/all-domain/globaldefault claim',decision='Thresholdcandidate gen2D4toD5, no depthloss on3controls including root-onlyorder loss; requirebound shadow andphaseabort/regressions beforeproduction.'))
print(summary)
