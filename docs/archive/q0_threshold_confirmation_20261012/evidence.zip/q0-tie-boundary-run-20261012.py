import sys,json,importlib.util,sysconfig
from pathlib import Path
R=Path.cwd();sys.path.insert(0,str(R))
import generic_chess.native as native
from scripts.research_record import write_record
base=R/'.local_agent/q0-tie-boundary-20261012'
write_record(base/'ep-declaration.json',dict(calls=12,fixture='existing Chess EP: e2e4 a7a6 e4e5 d7d5',depths=[2,3],tt=[0,1],profiles=['unit','zero','unit+oneKnight'],scope='All real root equal-upper threshold triggers shadowed by TTfree fullwindow same child horizon; unit scores force minimum integer losing boundary. Predeclared before queries; no changed root order, no adoption.'))
p=base/'shadow'/('_native_core'+sysconfig.get_config_var('EXT_SUFFIX'));spec=importlib.util.spec_from_file_location('boundary._native_core',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);native._MODULE=m
from generic_chess.native import semantic as ns
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from scripts.search_backend_comparison import CASES,CoreBoard
from types import SimpleNamespace
c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess'));core=CoreBoard(next(x for x in CASES if x['id']=='chess-ep'),c);session=SimpleNamespace(compiled=c,state=core.initial,_search_witnesses=core.witnesses);nr=NativeSemanticLegalityProvider.try_create(c,strict=True).native_rules;pos=pack_semantic_search_position(c,nr,session)
rows=[]
for profile,values in [('unit',dict(K=0,P=1,N=2,B=3,R=4,Q=5)),('zero',{t:0 for t in nr.type_ids}),('unit+oneKnight',dict(K=0,P=1,N=3,B=3,R=4,Q=5))]:
 for tt in [0,1]:
  for depth in [2,3]:
   before=ns.snapshot(nr,pos)
   r=ns.semantic_iterative_search(nr,pos,depth,board_values=values,hand_values=values,tt_megabytes=tt,root_window_pruning=True)
   assert r['completed_depth']==depth and r['shadow_mismatches']==0 and ns.snapshot(nr,pos)==before
   reference=ns.semantic_iterative_search(nr,pos,depth,board_values=values,hand_values=values,tt_megabytes=0,root_window_pruning=False)
   assert all(r[k]==reference[k] for k in ['score','best_action','principal_variation','completed_depth'])
   rows.append(dict(profile=profile,tt=tt,depth=depth,result=r,reference=reference))
tot={k:sum(x['result'][k] for x in rows) for k in ['shadow_checks','shadow_ties','shadow_losses','shadow_unit_losses','shadow_mismatches']}
write_record(base/'ep-result.json',dict(complete=True,rows=rows,totals=tot))
print(tot)
assert tot['shadow_ties']>0 and tot['shadow_unit_losses']>0
