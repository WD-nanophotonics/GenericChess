"""Existing frozen material ordering option, no learning or new search code."""
import sys,json,time,sysconfig,importlib.util
from pathlib import Path
from types import SimpleNamespace
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
import generic_chess.native as native
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess import compile_ruleset_for_execution
from generic_chess.core.position import GameState,HistoryRecord,Hands,Position
from generic_chess.core.pieces import Piece
from generic_chess.core.terminal import TerminalResult,TerminalStatus
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.learning.material import LearnableMaterialCheckpoint
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from scripts.research_record import record_value,write_record
out=ROOT/'.local_agent/q0-tie-abort-20261012';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
marker=next(x for x in json.loads((ROOT/'.local_agent/q0-tie-threshold-20261012/run/result.json').read_bytes())['rows'] if x['root']=='generated1091' and x['turn']==2 and x['arm']=='threshold1' and x['depth']==4 and x['order']==0)
limits={'refinement':marker['raw']['research_refine_start']+1,'final':marker['raw']['research_final_start']+64};assert marker['raw']['research_refine_end']-marker['raw']['research_refine_start']>=1
write_record(out/'declaration.json',dict(question='Do deterministic phase nodebudgets preserve previous complete tuple and persistentTT recovery?',calls=5,limits=limits,reference_depth=3,retry_depth=4,nodes_after_marker={'refinement':1,'final':64},seconds=64,q=0,scope='Phase markers from completed private candidate fullD4 before outcomes. Both maxnodes chosen before firstabort, independent freshengine perphase, same engine retrywithoutTTclear. Compare full D3 forabort/full coldD4 forretry; literal PV material not used as semantics oracle. Actual abort_origin and descendantTTstores recorded. Existing nodebudget interface, not phase-targeted actualcancel assertion. Expected<1min;max320s<6min; no rescue/rewrite ofearliercells.'))
modules={}
spec=importlib.util.spec_from_file_location('abort._native_core',ROOT/'.local_agent/q0-tie-guarded-20261012/threshold1'/('_native_core'+sysconfig.get_config_var('EXT_SUFFIX')));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);modules['phase']=m
inputs=json.loads((ROOT/'.local_agent/q0-consumer-resumed-20261012/inputs.json').read_bytes());saved=json.loads((ROOT/'.local_agent/q0-played-consumer-after-20261012/result.json').read_bytes())['paths']['generated1091'];inputs['generated1091']=dict(inputs['generated1091'],state=saved['turns'][2]['before'],witnesses=saved['initial_witnesses']+[x['after']['position'] for x in saved['turns'][:2]]);rows=[]
def position(d):
 d=dict(d);d['board']=tuple(Piece(**p) if p else None for p in d['board']);d['hands']=tuple(Hands(tuple(tuple(x) for x in h['counts'])) for h in d['hands']);d['aux_state']=tuple((tuple(k),tuple(v) if isinstance(v,list) else v) for k,v in d['aux_state']);return Position(**d)
for name,inp in inputs.items():
 if name!='generated1091':continue
 c=compile_ruleset_for_execution(ruleset_from_dict(json.loads(inp['rules'])));d=inp['state'];state=GameState(position(d['position']),d['ply_count'],tuple(tuple(x) for x in d['repetition_counts']),TerminalResult(TerminalStatus(d['terminal_status']['status']),**{k:v for k,v in d['terminal_status'].items() if k!='status'}),tuple(HistoryRecord(**h) for h in d['history']));witnesses=tuple(position(x) for x in inp['witnesses']);s=SimpleNamespace(compiled=c,state=state,_search_witnesses=witnesses,result=SimpleNamespace(status=SimpleNamespace(value='ongoing')));assert record_value(state)==d
 provider=NativeSemanticLegalityProvider.try_create(c,strict=True);profile=build_ruleset_profile(c,EvaluationConfig());checkpoint=LearnableMaterialCheckpoint.from_profile(c,profile,dynamic_weights={});write_record(out/(name+'-ordering.json'),checkpoint.to_dict());bv=inp['board'];hv=inp['hand']
 native._MODULE=m;provider=NativeSemanticLegalityProvider.try_create(c,strict=True)
 def engine():return SemanticSearchEngine(c,provider.native_rules,board_values=bv,hand_values=hv,dynamic_values=(0,0,0),evaluator_scale=1,tt_megabytes=1,ordering_checkpoint=checkpoint,ordering_min_depth=2)
 raw=[];old=m.semantic_engine_search
 def counted(*a):
  d=old(*a);raw.append(dict(d));return d
 m.semantic_engine_search=counted
 def call(e,label,depth,nodes):
  before=record_value(state);t=time.perf_counter();r=e.search(s,SearchLimits(max_depth=depth,max_nodes=nodes,max_time_seconds=64,quiescence_max_depth=0,quiescence_hard_max_depth=0),root_window_pruning=True);assert record_value(state)==before;ss=state
  for action in r.principal_variation:assert action in legal_actions(ss,c);ss=apply_action(ss,action,c)
  x=dict(label=label,seconds=time.perf_counter()-t,result=record_value(r),raw=raw[-1],pv_legal=True,root_restored=True);rows.append(x);write_record(out/'result.json',dict(complete=False,rows=rows));print(label,round(x['seconds'],3),r.completed_depth,r.score,r.nodes,raw[-1]['research_abort_origin'],raw[-1]['research_refine_stores'],flush=True);return x
 reference=call(engine(),'cold_D3',3,None)
 signature=lambda x:tuple(x['result'][k] for k in ['completed_depth','score','action','principal_variation'])
 for label,budget in limits.items():
  e=engine();limited=call(e,label+'_abort',4,budget);assert limited['result']['termination_reason']=='node_budget';assert signature(limited)==signature(reference);assert limited['raw']['research_abort_origin']==(1 if label=='refinement' else 2);assert limited['raw']['research_refine_stores']>=0
  recovered=call(e,label+'_warm_retry',4,None);assert signature(recovered)==signature(marker);assert recovered['raw']['research_pv_mismatches']==0
 m.semantic_engine_search=old
write_record(out/'result.json',dict(complete=True,rows=rows))
write_record(out/'verification.json',dict(complete=True,calls=len(rows),actual_phase_origins=[1,2],partial_refinement_descendant_stores_positive=True,aborts_publish_previous_full_D3=True,persistentTT_retry_full_cold_D4_match=True,all_completed_root_final_scores_match=True,actual_cancel_phase_targeted=False))
