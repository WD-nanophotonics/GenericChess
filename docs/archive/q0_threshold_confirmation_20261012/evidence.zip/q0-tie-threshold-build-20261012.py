import os,sys,json,time,sysconfig,subprocess,hashlib
from pathlib import Path
R=Path.cwd();sys.path.insert(0,str(R));from scripts.research_record import write_record
out=R/'.local_agent/q0-tie-threshold-20261012';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
s=(R/'.local_agent/q0-root-canonical-20261012/baseline/native_module.c').read_text(encoding='utf-8')
write_record(out/'declaration.json',dict(question='Can integer threshold tieconfirmation retain materialroot ordering andcanonicalfulltuple but avoid fullwindow confirmation cost?',base_sha='f1ea1d3870302777de6b56ae4cd62a17d7bf7bb0',calls=12,roots=['savedgen2'],depths=[4,5],arms=['baseline','threshold0','threshold1'],orders=[0,1],seconds=64,max_nodes=None,TT_MiB=1,ordering_min_depth=2,root_hint=None,scope='Changedpremise afteruniformrootcanonical rejects16s depthloss: existinginitial narrowed rootcandidate supplies UPPER==exactbest, childlower>=-best. Confirmation childwindow[-best,-best+1], classify <=-best tie, otherwise losing; neveraccept boundasrootimprovement. pv0/1 testsentryTTuse, fullfinalcanonicalreconstruction retained. Samefixedleaf/horizon/fullhistory, oldcapsimmutable. Privateonly/noUI/default/humanfit/extra workers. Max13min expectedunder2min, stopflagseachcell, norescue.'))
variants={'baseline':s}
needle='''            branch = gc_semantic_iterative_negamax(
                ctx, ply + 1, depth - 1, -GC_SEMANTIC_PROBE_INF,
                GC_SEMANTIC_PROBE_INF, 1, 0);'''
assert s.count(needle)==1
for pv in [0,1]:
 v=s.replace(needle,f'''            int confirmed_incumbent = best;
            branch = gc_semantic_iterative_negamax(
                ctx, ply + 1, depth - 1, -confirmed_incumbent,
                -confirmed_incumbent + 1, {pv}, 0);''')
 a='            score = -branch;\n        }';assert v.count(a)==1
 v=v.replace(a,'''            /* Combine the earlier root UPPER bound with this child threshold
             * test; a fail-low confirms equality, not a root improvement. */
            score = branch <= -confirmed_incumbent
                ? confirmed_incumbent : -branch;
        }''')
 variants['threshold'+str(pv)]=v
rows=[]
for arm,src in variants.items():
 d=out/arm;d.mkdir(exist_ok=True);p=d/'native_module.c';p.write_text(src,encoding='utf-8',newline='\n');binary=d/('_native_core'+sysconfig.get_config_var('EXT_SUFFIX'))
 args=[str(R/'.venv/Lib/site-packages/ziglang/zig.exe'),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+sysconfig.get_paths()['include'],'-I'+str(R/'generic_chess/_native'),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython312']+[str(p if f.name=='native_module.c' else f) for f in sorted((R/'generic_chess/_native').glob('*.c'))]+['-o',str(binary)]
 t=time.perf_counter();r=subprocess.run(args,env=dict(os.environ,ZIG_GLOBAL_CACHE_DIR=str(R/'.gc_zig_cache')),capture_output=True,text=True,timeout=180);(d/'compiler-private.txt').write_text(r.stdout+r.stderr,encoding='utf-8');assert r.returncode==0,r.stderr[-1000:];rows.append(dict(arm=arm,seconds=time.perf_counter()-t,source_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest()));print(arm,'built',flush=True)
write_record(out/'build.json',rows)
