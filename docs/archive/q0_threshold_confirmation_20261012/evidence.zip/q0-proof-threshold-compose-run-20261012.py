"""Isolated same-ABI nonroot AB-window variants, equal fixed controls and budgets."""
import sys,json,time,importlib.util,sysconfig
from pathlib import Path
from types import SimpleNamespace
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
import generic_chess.native as native
from generic_chess import compile_ruleset_for_execution
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.core.position import GameState,HistoryRecord,Hands,Position
from generic_chess.core.pieces import Piece
from generic_chess.core.terminal import TerminalResult,TerminalStatus
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from scripts.research_record import record_value,write_record
from generic_chess.learning.material import LearnableMaterialCheckpoint
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.config import EvaluationConfig
from scripts.search_backend_comparison import VALUES
from generic_chess import build_builtin_ruleset
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning

from scripts.full_q_refresh_comparison import SearchMetadataAdapter,compile_legacy_ruleset_for_semantic_execution
import hashlib,random
from generic_chess.generation.config import GeneratorConfig
from generic_chess.generation.generator import generate_game
from generic_chess.session.session import GameSession
from generic_chess.rules.serialization import serialize_ruleset
def position(d):
 d=dict(d);d['board']=tuple(Piece(**p) if p else None for p in d['board']);d['hands']=tuple(Hands(tuple(tuple(x) for x in h['counts'])) for h in d['hands']);d['aux_state']=tuple((tuple(k),tuple(v) if isinstance(v,list) else v) for k,v in d['aux_state']);return Position(**d)


from generic_chess.ai.cancellation import CancellationToken
base=ROOT/'.local_agent/q0-proof-threshold-compose-20261012';modules={}
for arm in ['proof']:
 sp=importlib.util.spec_from_file_location('boundary_'+arm+'._native_core',(base/'proof_injected')/('_native_core'+sysconfig.get_config_var('EXT_SUFFIX')));m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);modules[arm]=m

from generic_chess.session.session import GameSession
out=base/'consumer';out.mkdir(exist_ok=True);write_record(out/'declaration.json',dict(calls=12,roots='three savedactualimmediatewins plusfiveplywincontrol',policies=['duringproof_cancel','sameTT_retry','cold_retry'],seconds=8,maxdepth=3,scope='Actualnative cancel injection afterterminalproof beforeacceptance, four savedroots sameTTretry andcoldD3control, realGameSession no-submit. Currentthresholdsource. No UI/default/enum/training changes or OS callback latency claim.'))
samples=json.loads((ROOT/'.local_agent/q0-refine-generated-20261012/samples.json').read_bytes());rows=[]
for sample in samples:
 if not sample['included'] or sample['root'] not in ['seed2026101201-ply0','seed2026101203-ply0','seed2026101204-ply8','seed2026101203-ply8']:continue
 src=compile_legacy_ruleset_for_semantic_execution(ruleset_from_dict(sample['rules']));c=SearchMetadataAdapter(ir=src.ir,_legacy_compiled=src._legacy_compiled,support=src.support)
 d=sample['state'];state=GameState(position(d['position']),d['ply_count'],tuple(tuple(x) for x in d['repetition_counts']),TerminalResult(TerminalStatus(d['terminal_status']['status']),**{k:v for k,v in d['terminal_status'].items() if k!='status'}),tuple(HistoryRecord(**h) for h in d['history']));w=tuple(position(x) for x in sample['witnesses']);session=SimpleNamespace(compiled=c,state=state,_search_witnesses=w,result=SimpleNamespace(status=SimpleNamespace(value='ongoing')));assert record_value(state)==d
 bv=sample['board'];hv=sample['hand'];ordering=LearnableMaterialCheckpoint.from_profile(c,build_ruleset_profile(c,EvaluationConfig()),dynamic_weights={})



 native._MODULE=modules['proof'];provider=NativeSemanticLegalityProvider.try_create(c,strict=True)
 e=SemanticSearchEngine(c,provider.native_rules,board_values=bv,hand_values=hv,dynamic_values=(0,0,0),evaluator_scale=1,tt_megabytes=1,ordering_checkpoint=ordering,ordering_min_depth=2)
 signature=lambda r:(r.completed_depth,r.score,r.action,r.principal_variation)
 results=[]
 for policy in ['duringproof_cancel','sameTT_retry','cold_retry']:
  if policy=='cold_retry':
   e=SemanticSearchEngine(c,provider.native_rules,board_values=bv,hand_values=hv,dynamic_values=(0,0,0),evaluator_scale=1,tt_megabytes=1,ordering_checkpoint=ordering,ordering_min_depth=2)
  token=CancellationToken() if policy=='duringproof_cancel' else None
  real=GameSession(c);real._state=state;real._search_history_witnesses=w
  res=e.search(real,SearchLimits(max_depth=3,max_nodes=1000000,max_time_seconds=8,quiescence_max_depth=0),cancel_token=token,root_window_pruning=True)
  submitted=False
  if res.termination_reason not in ['cancelled','internal_error']:
   assert res.action in real.legal_actions();real.submit(res.action);submitted=True
  else:assert record_value(real.state)==record_value(state)
  if policy=='duringproof_cancel':assert res.termination_reason=='cancelled' and not submitted
  results.append(res)
  rows.append(dict(root=sample['root'],policy=policy,result=record_value(res),submitted=submitted,actual_session_result=record_value(real.result)))
 assert signature(results[1])==signature(results[2])
write_record(out/'result.json',dict(complete=True,rows=rows))
write_record(out/'verification.json',dict(calls=len(rows),duringproof_cancel_no_submit=4,sameTT_cold_fulltuple_pairs=4,scope='Currentthreshold+canonicalreconstruction +guardedproof composition. Actual nativecancel flag afterterminalcheck; realGameSessionconsumer no-submit. FixedD3 retries; noOS/usercallbacklatency orUIproofpolicy adoption.'))
print('12actual duringproof cancel/retry/cold calls pass')
