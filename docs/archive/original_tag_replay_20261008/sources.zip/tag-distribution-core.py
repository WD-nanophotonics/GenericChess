"""Independent Core replay and exact conditional tagged-reward distribution."""
import sys,json,time,hashlib
from fractions import Fraction as F
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.transition import initial_state,apply_action
from generic_chess.core.movegen import legal_actions
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;prior=ROOT/'.local_agent/custody-kernel-20261008';raw=(ROOT/'docs/archive/original_horizon_preflight_20261008/remaining-custody.json').read_bytes();src=json.loads(raw);mass=json.loads((p/'tag-mass.json').read_bytes());cases=json.loads((prior/'kernel-completed.json').read_bytes())['cases'];frontiers=sorted(json.loads((prior/'pretransfer-coupling.json').read_bytes())['frontiers'],key=lambda x:x['seed']);out=p/'tag-distribution-core.json';assert not out.exists();start=time.perf_counter()
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),source_sha256=hashlib.sha256(raw).hexdigest(),declaration='All208 original saved action paths, independently executed with Core. Enumerate latent tag location/holder AND cumulative integer signed reward with exact rational probabilities, not a first-moment Native recurrence. Each same-base hand drop branches tag1/count versus another token(count-1)/count. Merge only identical latent state/reward. Conditional distribution/variance does not eliminate sampled action-path/prefix uncertainty. Original64 weighting; no material-price claim.',cells=[],core_transitions=0,peak_latent_states=0)
for j,case in enumerate(cases):
 c=compile_ruleset_for_execution(ruleset_from_dict(case['definition']));base=case['base'];anchors={t.type_id for t in c.piece_types if t.is_anchor}
 for f in frontiers:
  state=initial_state(c)
  for v in f['paired_actions'][j]:state=apply_action(state,next(a for a in legal_actions(state,c) if record_value(a)==v),c)
  root=state;cell=next(x for x in src['cells'] if x['frontier_seed']==f['seed'] and x['base']==base);m=next(x for x in mass['cells'] if x['frontier_seed']==f['seed'] and x['base']==base);row=dict(frontier_seed=f['seed'],base=base,trials=[])
  for trial in cell['trials']:
   assert not json.loads((ROOT/'.local_agent/rollout.json').read_bytes()).get('user_paused')
   state=root;latent={(None,1,0):F(1)}
   for v in trial['actions']:
    board=state.position.board;owner=state.position.side_to_move;next_latent={}
    def add(key,prob):
     if prob:next_latent[key]=next_latent.get(key,F(0))+prob
    for (tag,holder,reward),prob in latent.items():
     if 'from_square' in v:
      origin=v['from_square']['file']+9*v['from_square']['rank'];target=v['to_square']['file']+9*v['to_square']['rank'];victim=board[target]
      if tag==origin:
       if victim is not None and victim.owner!=owner and victim.current_type_id not in anchors:reward+=1 if owner==0 else -1
       tag=target
      elif tag==target:assert victim is not None and victim.base_type_id==base;tag=None;holder=owner
      add((tag,holder,reward),prob)
     elif v['base_type_id']==base and holder==owner:
      count=state.position.hands[owner].count(base);assert count>=1;target=v['to_square']['file']+9*v['to_square']['rank']
      add((target,None,reward),prob/count);add((None,owner,reward),prob*(count-1)/count)
     else:add((tag,holder,reward),prob)
    latent=next_latent;assert sum(latent.values())==1;r['peak_latent_states']=max(r['peak_latent_states'],len(latent));assert len(latent)<=10000
    state=apply_action(state,next(a for a in legal_actions(state,c) if record_value(a)==v),c);r['core_transitions']+=1
    for tag,holder,_ in latent:
     if tag is None:assert state.position.hands[holder].count(base)>=1
     else:assert state.position.board[tag] is not None and state.position.board[tag].base_type_id==base
   distribution={}
   for (_,_,reward),prob in latent.items():distribution[reward]=distribution.get(reward,F(0))+prob
   expected=sum(k*v for k,v in distribution.items());assert str(expected)==m['trials'][trial['repeat']]['conditional_reward'];variance=sum((k-expected)**2*v for k,v in distribution.items())
   row['trials'].append(dict(repeat=trial['repeat'],reward_distribution=distribution,expected=expected,variance=variance,latent_states=len(latent)))
  r['cells'].append(row);write_record(out,r)
assert r['core_transitions']==4320
r.update(complete=True,nonzero_variance_paths=sum(t['variance']!=0 for x in r['cells'] for t in x['trials']),sum_conditional_variance=sum(t['variance'] for x in r['cells'] for t in x['trials']),seconds=time.perf_counter()-start);write_record(out,r);print({k:record_value(r[k]) for k in ('core_transitions','peak_latent_states','nonzero_variance_paths','sum_conditional_variance','seconds')})
