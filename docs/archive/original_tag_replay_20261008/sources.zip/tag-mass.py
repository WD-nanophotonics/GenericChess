"""Exact latent tag allocation on fixed observed Native action paths."""
import sys,json,time,hashlib
from fractions import Fraction as F
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.semantic import guarded_actions,public_action,make_checked,snapshot
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;prior=ROOT/'.local_agent/custody-kernel-20261008'
raw=(ROOT/'docs/archive/original_horizon_preflight_20261008/remaining-custody.json').read_bytes();src=json.loads(raw)
defs=(prior/'kernel-completed.json').read_bytes();cases=json.loads(defs)['cases']
frontier_raw=(prior/'pretransfer-coupling.json').read_bytes();frontiers=sorted(json.loads(frontier_raw)['frontiers'],key=lambda x:x['seed'])
out=p/'tag-mass.json';assert not out.exists();started=time.perf_counter()
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),source_sha256=hashlib.sha256(raw).hexdigest(),definition_sha256=hashlib.sha256(defs).hexdigest(),prior_sha256=hashlib.sha256(frontier_raw).hexdigest(),declaration='Condition on each existing full legal action path, under the declared uniform behavioral policy independent of latent tag identity. Exact probability mass over board squares and owner hands, total1. Same-base drop assigns hand mass/count to dropped square; tag capture moves mass into capturing hand. Reward is signed probability that actual capturing actor is tag. Removes latent-allocation MC noise; action-path and original-prefix uncertainty remain. Not deterministic equality with previous sampled tag coin/RNG sequence.',cells=[],native_transitions=0)
write_record(out,r)
for j,case in enumerate(cases):
 c=compile_ruleset_for_execution(ruleset_from_dict(case['definition']));n=compile_native_semantic_rules(c);ids={t:i for i,t in enumerate(n.type_ids)};base=ids[case['base']];anchors={ids[t.type_id] for t in c.piece_types if t.is_anchor}
 for fi,f in enumerate(frontiers):
  session=GameSession(c)
  for v in f['paired_actions'][j]:session.submit(next(a for a in session.legal_actions() if record_value(a)==v))
  root=pack_semantic_search_position(c,n,session);cell=next(x for x in src['cells'] if x['frontier_seed']==f['seed'] and x['base']==case['base']);row=dict(frontier_seed=f['seed'],base=case['base'],remaining=cell['remaining'],trials=[])
  for t in cell['trials']:
   assert not json.loads((ROOT/'.local_agent/rollout.json').read_bytes()).get('user_paused')
   pos=root;board={};hands=[F(0),F(1)];reward=F(0);events=[]
   for ply,v in enumerate(t['actions']):
    before=snapshot(n,pos);owner=before['side']
    if 'from_square' in v:
     origin=v['from_square']['file']+9*v['from_square']['rank'];target=v['to_square']['file']+9*v['to_square']['rank'];victim=before['board'][target]
     actor_mass=board.pop(origin,F(0));victim_mass=board.pop(target,F(0))
     if victim is not None and victim[2]!=owner and victim[1] not in anchors and actor_mass:
      delta=actor_mass*(1 if owner==0 else -1);reward+=delta;events.append(dict(ply=ply,owner=owner,reward=delta))
     if victim_mass:assert victim is not None and victim[0]==base;hands[owner]+=victim_mass
     if actor_mass:board[target]=actor_mass
    elif ids[v['base_type_id']]==base:
     target=v['to_square']['file']+9*v['to_square']['rank'];count=before['hands'][owner][base];assert count>=1
     assigned=hands[owner]/count;hands[owner]-=assigned
     if assigned:assert target not in board;board[target]=assigned
    action=next(a for a in guarded_actions(n,pos) if record_value(public_action(n,a))==v);pos=make_checked(n,pos,action);r['native_transitions']+=1
    after=snapshot(n,pos);assert sum(board.values())+sum(hands)==1
    assert all(q>=0 for q in [*board.values(),*hands])
    assert all(after['board'][sq] is not None and after['board'][sq][0]==base for sq in board)
    assert all(not hands[o] or after['hands'][o][base]>=1 for o in (0,1))
   row['trials'].append(dict(repeat=t['repeat'],conditional_reward=reward,sampled_reward=t['reward'],events=events,final_board_mass=board,final_hand_mass=hands))
  r['cells'].append(row);write_record(out,r)
bykey={(x['frontier_seed'],x['base']):x for x in r['cells']}
diffs=[sum(bykey[(f['seed'],'G')]['trials'][j]['conditional_reward']-bykey[(f['seed'],'P')]['trials'][j]['conditional_reward'] for f in frontiers)/64 for j in range(8)]
r.update(complete=True,original_population_repeat_differences=diffs,mean_difference=sum(diffs)/8,seconds=time.perf_counter()-started);write_record(out,r);print('exact latent mass means',record_value(diffs),'overall',str(sum(diffs)/8),'seconds',r['seconds'])
