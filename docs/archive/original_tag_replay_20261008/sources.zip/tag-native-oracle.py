"""Independent Native replay of declared remaining-horizon custody paths."""
import sys,json,random,time,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.semantic import guarded_actions,public_action,make_checked,snapshot,terminal_status
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;prior=ROOT/'.local_agent/custody-kernel-20261008'
raw=(ROOT/'docs/archive/original_horizon_preflight_20261008/remaining-custody.json').read_bytes();src=json.loads(raw)
defs=(prior/'kernel-completed.json').read_bytes();cases=json.loads(defs)['cases']
frontier_raw=(prior/'pretransfer-coupling.json').read_bytes();frozen=json.loads(frontier_raw)
frontiers=sorted(frozen['frontiers'],key=lambda x:x['seed']);byseed={x['seed']:x for x in frontiers}
out=p/'tag-native-oracle.json';assert not out.exists();started=time.perf_counter()
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),source_sha256=hashlib.sha256(raw).hexdigest(),definition_sha256=hashlib.sha256(defs).hexdigest(),prior_sha256=hashlib.sha256(frontier_raw).hexdigest(),declaration='All208 saved paths independently tracked in guarded Native board/hand/history states. Reconstruct uniform action RNG and exchangeable hand draws against Native legal actions. Compare full service events, terminal and original64 weights; no Core continuation reused. This checks observed paths, not population precision/material prices.',rows=[],native_transitions=0)
write_record(out,r);rewards={}
for j,case in enumerate(cases):
 c=compile_ruleset_for_execution(ruleset_from_dict(case['definition']));n=compile_native_semantic_rules(c);ids={t:i for i,t in enumerate(n.type_ids)};base=ids[case['base']];anchors={ids[t.type_id] for t in c.piece_types if t.is_anchor}
 for fi,f in enumerate(frontiers):
  session=GameSession(c)
  for v in f['paired_actions'][j]:session.submit(next(a for a in session.legal_actions() if record_value(a)==v))
  assert record_value(session.state)==f['paired_states'][j];root=pack_semantic_search_position(c,n,session)
  cell=next(x for x in src['cells'] if x['frontier_seed']==f['seed'] and x['base']==case['base']);assert cell['remaining']==32-f['ply']
  for trial in cell['trials']:
   assert not json.loads((ROOT/'.local_agent/rollout.json').read_bytes()).get('user_paused')
   rng=random.Random(2026100811+100*fi+trial['repeat']);pos=root;tag=None;holder=1;reward=0;events=[]
   assert snapshot(n,pos)['hands'][holder][base]>=1
   for ply,v in enumerate(trial['actions']):
    assert ply<cell['remaining'];before=snapshot(n,pos);owner=before['side'];assert not terminal_status(n,pos)['status']!='ongoing'
    legal=sorted(guarded_actions(n,pos),key=lambda a:json.dumps(record_value(public_action(n,a)),sort_keys=True));chosen=legal[rng.randrange(len(legal))]
    assert record_value(public_action(n,chosen))==v
    if 'from_square' in v:
     origin=v['from_square']['file']+9*v['from_square']['rank'];target=v['to_square']['file']+9*v['to_square']['rank'];victim=before['board'][target]
     if origin==tag:
      if victim is not None and victim[2]!=owner and victim[1] not in anchors:reward+=1 if owner==0 else -1;events.append(dict(ply=ply,owner=owner))
      tag=target
     elif target==tag:
      assert victim is not None and victim[0]==base;tag=None;holder=owner
    elif holder==owner and ids[v['base_type_id']]==base:
     count=before['hands'][holder][base];assert count>=1
     if rng.randrange(count)==0:tag=v['to_square']['file']+9*v['to_square']['rank'];holder=None
    pos=make_checked(n,pos,chosen);r['native_transitions']+=1;after=snapshot(n,pos)
    if tag is None:assert holder in (0,1) and after['hands'][holder][base]>=1
    else:assert after['board'][tag] is not None and after['board'][tag][0]==base
    assert after['history_exact'] and after['history_events_exact']
   terminal=terminal_status(n,pos);assert terminal['status']==trial['terminal']['status'] and terminal['winner']==trial['terminal']['winner']
   assert len(trial['actions'])==cell['remaining'] or terminal['status']!='ongoing'
   assert reward==trial['reward'] and events==trial['events'];rewards[(fi,j,trial['repeat'])]=reward
   r['rows'].append(dict(frontier_seed=f['seed'],base=case['base'],repeat=trial['repeat'],plies=len(trial['actions']),reward=reward,service_events=events,legal_rng_replay_equal=True,terminal_equal=True))
  write_record(out,r)
assert len(r['rows'])==208 and r['native_transitions']==src['transitions']
diffs=[sum(rewards[(i,0,j)]-rewards[(i,1,j)] for i in range(13))/64 for j in range(8)]
assert diffs==src['original_population_repeat_differences'] and sum(diffs)/8==src['mean_difference']
r.update(complete=True,original_population_repeat_differences=diffs,mean_difference=sum(diffs)/8,seconds=time.perf_counter()-started);write_record(out,r);print(json.dumps({k:r[k] for k in ('native_transitions','mean_difference','seconds')}))
